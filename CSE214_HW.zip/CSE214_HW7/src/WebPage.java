import java.util.ArrayList;
/**
 * The WebPage class represents a hyperlinked document.
 * The WebPage class should contain a String member variable for its URL, an int to represent its position in the adjacency matrix, an int to represent the rank (described later in the specs) of this WebPage, as well as a Collection of Strings containing the keywords describing this this page.
 * 
 * @author Samuel Ng
 * 	e-mail: samuel.ng@stonybrook.edu
 *	Stony Brook ID: 112330868
 */
public class WebPage {
	
	private String url;
	private int index;
	private int rank;
	private ArrayList<String> keywords;
	
	private String links;
	/**
	 * 
	 * @param url
	 * 	the url of the webpage
	 * @param index
	 * 	the index number on the webgraph
	 * @param keywords
	 * 	the collection of keywords
	 */
	public WebPage(String url, int index, ArrayList<String> keywords) {
		this.url = url;
		this.index = index;
		this.keywords = keywords;
		links = "***";
	}
	//Accessor methods:
	/**
	 * 
	 * @return
	 * 	the url of the webpage
	 */
	public String getURL() {
		return url;
	}
	/**
	 * 
	 * @return
	 * 	the index number on the webgraph
	 */
	public int getIndex() {
		return index;
	}
	/**
	 * 
	 * @return
	 * 	the ranking based on links to the webpage
	 */
	public int getRank() {
		return rank;
	}
	/**
	 * 
	 * @return
	 * 	the collection of associated keywords
	 */
	public ArrayList<String> getKeywords() {
		return keywords;
	}
	//Mutator methods:
	/**
	 * 
	 * @param url
	 * 	the new url of the webpage
	 */
	public void setURL(String url) {
		this.url = url;
	}
	/**
	 * 
	 * @param index
	 * 	the new index on the webgraph
	 */
	public void setIndex(int index) {
		this.index = index;
	}
	/**
	 * 
	 * @param rank
	 * 	the new ranking of the webpage
	 */
	public void setRank(int rank) {
		this.rank = rank;
	}
	/**
	 * 
	 * @param links
	 * 	the new string of links to other webpages
	 */
	public void setLinks(String links) {
		this.links = links;
	}
	/**
	 * @return
	 * 	string of data members in tabular form
	 */
	public String toString() {
		return String.format("%-5s|%-20s|%-9s|%-19s|%-50s", "  "+index+"  ", url, "    "+rank+"    ", links, keywords);
	}
}
