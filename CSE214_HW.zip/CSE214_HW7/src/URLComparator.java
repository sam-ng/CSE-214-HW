import java.util.Comparator;
/**
 * 
 * @author Samuel Ng
 * 	e-mail: samuel.ng@stonybrook.edu
 *	Stony Brook ID: 112330868
 */
public class URLComparator implements Comparator{
	public int compare(Object o1, Object o2) {
		WebPage p1 = (WebPage) o1;
		WebPage p2 = (WebPage) o2;
		return (p1.getURL().compareTo(p2.getURL()));
	}
}
