import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
/**
 * The WebGraph class organizes the WebPage objects as a directed graph.
 * 
 * @author Samuel Ng
 * 	e-mail: samuel.ng@stonybrook.edu
 *	Stony Brook ID: 112330868
 */
public class WebGraph {

	public static final int MAX_PAGES = 40;
	private ArrayList<WebPage> pages = new ArrayList<WebPage>(); //the collection of webpages
	private int[][] edges = new int[MAX_PAGES][MAX_PAGES]; //the adjacency matrix
	
	private boolean linkChange;
	/**
	 * Constructs a WebGraph object using the indicated files as the source for pages and edges.
	 * 
	 * @param pagesFile
	 * 	String of the relative path to the file containing the page information.
	 * @param linksFile
	 * 	String of the relative path to the file containing the link information.
	 * <dt>Preconditions:<dt>
	 * 	<dd>Both parameters reference text files which exist.</dd>
	 * 	<dd>The files follow proper format as outlined in the "Reading Graph from File" section below.</dd>
	 * <dt>Postconditions:<dt>
	 * 	<dd>A WebGraph has been constructed and initialized based on the text files.
	 * @return
	 * 	The WebGraph constructed from the text files.
	 * @throws IllegalArgumentException
	 * 	if either of the files does not reference a valid text file, or if the files are not formatted correctly.
	 * @throws IOException
	 */
	public static WebGraph buildFromFiles(String pagesFile, String linksFile) throws IllegalArgumentException, IOException {
		if (pagesFile == null)
			throw new IllegalArgumentException("Invalid pagesFile!");
		if (linksFile == null)
			throw new IllegalArgumentException("Invalid linksFile");
		FileInputStream fisPage = new FileInputStream(pagesFile);
		InputStreamReader inStreamPage = new InputStreamReader(fisPage);
		BufferedReader readerPage = new BufferedReader(inStreamPage);
		
		WebGraph graph = new WebGraph();
		
		String pageLine = readerPage.readLine();
		while (pageLine != null) {
			String[] pageArr = pageLine.trim().split(" ");
			String url = pageArr[0];
			ArrayList<String> keywords = new ArrayList<String>();
			for (int i = 1; i < pageArr.length; i++) {
				keywords.add(pageArr[i]);
			}
			graph.addPage(url, keywords);
			pageLine = readerPage.readLine();
		}
		readerPage.close();
		
		FileInputStream fisLink = new FileInputStream(linksFile);
		InputStreamReader inStreamLink = new InputStreamReader(fisLink);
		BufferedReader readerLink = new BufferedReader(inStreamLink);
		
		String linkLine = readerLink.readLine();
		while (linkLine != null) {
			String[] linkArr = linkLine.trim().split(" ");
			String source = linkArr[0];
			String destination = linkArr[1];
			graph.addLink(source, destination);
			linkLine = readerLink.readLine();
		}
		readerLink.close();
		graph.updatePageRanks();
		graph.updateLinks();
		return graph;
	}
	/**
	 * Adds a page to the WebGraph.
	 * @param url
	 * 	The URL of the webpage.
	 * @param keywords
	 * 	The keywords associated with the WebPage.
	 * <dt>Preconditions:</dt>
	 * 	<dd>url is unique and does not exist as the URL of a WebPage already in the graph.</dd>
	 * 	<dd>url and keywords are not null.</dd>
	 * <dt>Postconditions:</dt>
	 * 	<dd>The page has been added to pages at index "i" and links has been logically extended to include the new row and column indexed by "i".</dd>
	 * @throws IllegalArgumentException
	 * 	if url is not unique and already exists in the graph, or if either argument is null.
	 */
	public void addPage(String url, ArrayList<String> keywords) throws IllegalArgumentException {
		if (url == null)
			throw new IllegalArgumentException("The URL is null.");
		if (keywords == null)
			throw new IllegalArgumentException("The list of keywords is null.");
		for (int i = 0; i < pages.size(); i++) {
			if (pages.get(i).getURL().equals(url))
				return;
		}
		pages.add(new WebPage(url, pages.size(), keywords));
	}
	/**
	 * Adds a link from the WebPage with the URL indicated by source to the WebPage with the URL indicated by destination
	 * 
	 * @param source
	 * 	the URL of the page which contains the hyperlink to destination.
	 * @param destination
	 * 	the URL of the page which the hyperlink points to.
	 * <dt>Preconditions:<dt>
	 * 	<dd>Both parameters reference WebPages which exist in the graph.</dd>
	 * @throws IllegalArgumentException
	 * 	If either of the URLs are null or could not be found in pages
	 */
	public void addLink(String source, String destination) throws IllegalArgumentException {
		if (source == null)
			throw new IllegalArgumentException("The source URL is null.");
		if (destination == null)
			throw new IllegalArgumentException("The destination URL is null.");
		int sourceIndex = 0;
		int destinationIndex = 0;
		boolean foundSource = false;
		boolean foundDestination = false;
		for (int i = 0; i < pages.size(); i++) {
			if (pages.get(i).getURL().equals(source)) {
				sourceIndex = pages.get(i).getIndex();
				foundSource = true;
				break;
			}
		}
		for (int j = 0; j < pages.size(); j++) {
			if (pages.get(j).getURL().equals(destination)) {
				destinationIndex = pages.get(j).getIndex();
				foundDestination = true;
				break;
			}
		}
		try {
			if (!foundSource)
				throw new IllegalArgumentException("The source URL could not be found in pages.");
		}
		catch (IllegalArgumentException e) {
			System.out.println("Error: "+source+" could not be found in the WebGraph");
			return;
		}
		try {
			if (!foundDestination)
				throw new IllegalArgumentException("The source URL could not be found in pages.");
		}
		catch (IllegalArgumentException e) {
			System.out.println("Error: "+destination+" could not be found in the WebGraph");
			return;
		}
		linkChange = true;
		edges[sourceIndex][destinationIndex]++;
		updatePageRanks();
		updateLinks();
	}
	/**
	 * Removes the WebPage from the graph with the given URL.
	 * 
	 * @param url
	 * 	The URL of the page to remove from the graph.
	 * <dt>Postconditions:</dt>
	 * 	<dd>The WebPage with the indicated URL has been removed from the graph, and it's corresponding row and column has been removed from the adjacency matrix</dd>
	 * 	<dd>All pages that has an index greater than the index that was removed should decrease their index value by 1.</dd>
	 * 	<dd>If url is null or could not be found in pages, the method ignores the input and does nothing.</dd>
	 * @throws IllegalArgumentException
	 */
	public void removePage(String url) throws IllegalArgumentException{
		if (url == null)
			throw new IllegalArgumentException("The url is null.");
		int pageIndex = 0;
		boolean found = false;
		for (int i = 0; i < pages.size(); i++) {
			if (pages.get(i).getURL().equals(url)) {
				pageIndex = i;
				pages.remove(i);
				found = true;
				for (int j = i; j < pages.size(); j++) {
					int currentIndex = pages.get(j).getIndex();
					pages.get(j).setIndex(currentIndex-1);
				}
				break;
			}
		}
		if (!found)
			return;
		for (int k = 0; k < pages.size(); k++) {
			for (int l = pageIndex; l < pages.size(); l++) {
				edges[l][k] = edges[l+1][k];
			}
		}
		for (int x = 0; x < pages.size(); x++) {
			for (int y = pageIndex; y < pages.size(); y++) {
				edges[x][y] = edges[x][y+1];
			}
		}
		for (int m = 0; m < edges.length; m++) {
			for (int n = pages.size(); n < edges.length; n++) {
				edges[n][m] = 0;
				edges[m][n] = 0;
			}
		}
		updatePageRanks();
		updateLinks();
	}
	/**
	 * Removes the link from WebPage with the URL indicated by source to the WebPage with the URL indicated by destination.
	 * 
	 * @param source
	 * 	the url of the webpage to remove the link
	 * @param destination
	 * 	the url of the link to be removed
	 * <dt>Postconditions:</dt>
	 * 	<dd>The entry in links for the specified hyperlink has been set to 0 (no link).</dd>
	 * 	<dd>If either of the URLs could not be found, the input is ignored and the method does nothing.</dd>
	 * @throws IllegalArgumentException
	 */
	public void removeLink(String source, String destination) throws IllegalArgumentException {
		if (source == null)
			throw new IllegalArgumentException("The source URL is null.");
		if (destination == null)
			throw new IllegalArgumentException("The destination URL is null.");
		int sourceIndex = 0;
		int destinationIndex = 0;
		boolean foundSource = false;
		boolean foundDestination = false;
		for (int i = 0; i < pages.size(); i++) {
			if (pages.get(i).getURL().equals(source)) {
				sourceIndex = pages.get(i).getIndex();
				foundSource = true;
				break;
			}
		}
		for (int j = 0; j < pages.size(); j++) {
			if (pages.get(j).getURL().equals(destination)) {
				destinationIndex = pages.get(j).getIndex();
				foundDestination = true;
				break;
			}
		}
		try {
			if (!foundSource)
				throw new IllegalArgumentException("The source URL could not be found in pages.");
		}
		catch (IllegalArgumentException e) {
			System.out.println("Error: "+source+" could not be found in the WebGraph");
			return;
		}
		try {
			if (!foundDestination)
				throw new IllegalArgumentException("The source URL could not be found in pages.");
		}
		catch (IllegalArgumentException e) {
			System.out.println("Error: "+destination+" could not be found in the WebGraph");
			return;
		}
		linkChange = true;
		edges[sourceIndex][destinationIndex]--;
		updatePageRanks();
		updateLinks();
	}
	/**
	 * Calculates and assigns the PageRank for every page in the WebGraph
	 * 
	 * <dt>Postconditions:</dt>
	 * 	<dd>All WebPages in the graph have been assigned their proper PageRank.</dd>
	 */
	public void updatePageRanks() {
		int rank = 0;
		for (int j = 0; j < pages.size(); j++) {
			for (int i = 0; i < pages.size(); i++) {
				rank += edges[i][j];
			}
			WebPage currentPage = pages.get(j);
			currentPage.setRank(rank);
			pages.set(j, currentPage);
			rank = 0;
		}
	}
	/**
	 * Prints the WebGraph in tabular form
	 */
	public void printTable() {
		String table = "";
		table += String.format("%-5s %-20s %-9s %-19s %-50s", "Index", "URL", "PageRank", "Links", "Keywords") + "\n";
		int separatorLength = table.length();
		for (int i = 0; i < separatorLength; i++) {
			table += "-";
		}
		table += "\n";
		for (int j = 0; j < pages.size(); j++) {
			table += pages.get(j);
			table += "\n";
		}
		System.out.println(table);
	}
	
	public ArrayList<WebPage> getPages() {
		return pages;
	}
	
	public void updateLinks() {
		for (int i = 0; i < pages.size(); i++) {
			String links = "";
			for (int j = 0; j < pages.size(); j++) {
				if (edges[i][j] == 1)
					links += j + ", ";
			}
			if (links.length() > 0)
				links = links.substring(0, links.length()-2);
			WebPage currentPage = pages.get(i);
			currentPage.setLinks(links);
			pages.set(i, currentPage);
		}
	}
	
	public String searchTable(String keyword) {
		String table = "";
		table += String.format("%-5s %-9s %-20s", "Rank", "PageRank", "URL") + "\n";
		int separatorLength = table.length();
		for (int i = 0; i < separatorLength; i++) {
			table += "-";
		}
		table += "\n";
		int index = 1;
		for (int j = 0; j < pages.size(); j++) {
			if (pages.get(j).getKeywords().contains(keyword)) {
				table += String.format("%-5s|%-9s|%-20s", index, pages.get(j).getRank(), pages.get(j).getURL());
				table += "\n";
				index++;
			}
		}
		if (index > 1)
			return table;
		table = "No search results found for the keyword " + keyword+".";
		return table;
	}
	
	public boolean isLinkChange()  {
		return linkChange;
	}
	
	public void setLinkChange(boolean linkChange) {
		this.linkChange = linkChange;
	}
}
