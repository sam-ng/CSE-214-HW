import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
/**
 * The SearchEngine class will intialize a WebGraph from the appropriate text files and allow the uwer to search for keywords in the graph.
 * 
 * @author Samuel Ng
 * 	e-mail: samuel.ng@stonybrook.edu
 *	Stony Brook ID: 112330868
 */
public class SearchEngine {
	public static final String PAGES_FILE = "pages.txt";
	public static final String LINKS_FILE = "links.txt";
	
	private static boolean run;
	
	private static WebGraph web;
	/**
	 * Provide a menu prompt and implement the following menu options
	 * @param args
	 */
	public static void main(String[] args) {
		run = true;
		web = new WebGraph();
		Scanner sc = new Scanner(System.in);
		System.out.println("Loading WebGraph data...");
		try {
			web = WebGraph.buildFromFiles(PAGES_FILE, LINKS_FILE);
			Collections.sort(web.getPages(), new IndexComparator());
			System.out.println("Success!");
		} catch (IllegalArgumentException e) {
			System.out.println("The files are invalid.");
		} catch (IOException e) {
			System.out.println("ERROR! IO exception");
		}
		while (run) {
			System.out.println();
			System.out.println("Menu: ");
			System.out.println("\t(AP) - Add a new page to the graph.");
			System.out.println("\t(RP) - Remove a page from the graph.");
			System.out.println("\t(AL) - Add a link between pages in the graph.");
			System.out.println("\t(RL) - Remove a link between pages in the graph.");
			System.out.println("\t(P)  - Print the graph.");
			System.out.println("\t(S)  - Search for pages with a keyword.");
			System.out.println("\t(Q)  - Quit.");
			System.out.println();
			System.out.print("Please select an option: ");
			String option = sc.nextLine().toUpperCase();
			switch (option) {
				case "AP":
					System.out.print("Enter a URL: ");
					String url = sc.nextLine();
					System.out.print("Enter keywords (space-separated): ");
					String keywords = sc.nextLine();
					String[] keywordArr = keywords.trim().split(" ");
					ArrayList<String> keywordList = new ArrayList<String>();
					for (int i = 0; i < keywordArr.length; i++) {
						keywordList.add(keywordArr[i]);
					}
					int pageSize = web.getPages().size();
					web.addPage(url, keywordList);
					System.out.println();
					if (pageSize == web.getPages().size())
						System.out.println("Error: "+url+" already exists in the WebGraph. Could not add new WebPage.");
					else
						System.out.println(url + " successfully added to the WebGraph!");
					break;
				case "RP":
					System.out.print("Enter a URL: ");
					url = sc.nextLine();
					pageSize = web.getPages().size();
					web.removePage(url);
					System.out.println();
					if (pageSize == web.getPages().size())
						System.out.println("Error: "+url+" could not be found in the WebGraph");
					else
						System.out.println(url + " has been removed from the graph!");
					break;
				case "AL":
					System.out.print("Enter a source URL: ");
					String source = sc.nextLine();
					System.out.print("Enter a destination URL: ");
					String destination = sc.nextLine();
					System.out.println();
					web.addLink(source, destination);
					if (web.isLinkChange())
						System.out.println("Link successfully added from " + source + " to " + destination + "!");
					web.setLinkChange(false);
					break;
				case "RL":
					System.out.print("Enter a source URL: ");
					source = sc.nextLine();
					System.out.print("Enter a destination URL: ");
					destination = sc.nextLine();
					System.out.println();
					web.removeLink(source, destination);
					if (web.isLinkChange())
						System.out.println("Link successfully removed from " + source + " to " + destination + "!");
					web.setLinkChange(false);
					break;
				case "P":
					System.out.println();
					System.out.println("\t(I) Sort based on index (ASC)");
					System.out.println("\t(U) Sort based on URL (ASC)");
					System.out.println("\t(R) Sort based on rank (DSC)");
					while (true) {
						System.out.println();
						System.out.print("Please select an option: ");
						option = sc.nextLine().toUpperCase();
						if (option.equals("I")) {
							Collections.sort(web.getPages(), new IndexComparator());
							break;
						}
						else if (option.equals("U")) {
							Collections.sort(web.getPages(), new URLComparator());
							break;
						}
						else if (option.equals("R")) {
							Collections.sort(web.getPages(), new RankComparator());
							break;
						}
						else {
							System.out.println("Invalid option.");
						}
					}
					web.printTable();
					Collections.sort(web.getPages(), new IndexComparator());
					break;
				case "S":
					System.out.print("Search keyword: ");
					String keyword = sc.nextLine();
					System.out.println();
					Collections.sort(web.getPages(), new RankComparator());
					System.out.println(web.searchTable(keyword));
					Collections.sort(web.getPages(), new IndexComparator());
					break;
				case "Q":
					System.out.println();
					System.out.println("Goodbye.");
					run = false;
					System.exit(0);
					break;
				default:
					System.out.println("Invalid option.");
			}
		}
	}
}
