
public class ClosedAuctionException extends Exception {

	public ClosedAuctionException(String s) {
		super(s);
	}
}
